# vaccination-impact-model
A python system that models and visualises the effect of social influences on the impact of vaccination decisions in individuals 
